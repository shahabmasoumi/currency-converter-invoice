<?php

class Currency_Converter_Invoice {

    public function run() {
        add_action('admin_menu', array($this, 'add_plugin_page'));
        add_action('admin_init', array($this, 'page_init'));
        add_shortcode('currency_invoice', array($this, 'currency_invoice_shortcode'));
        add_shortcode('currency_converter', array($this, 'currency_converter_shortcode'));
        add_action('wp_ajax_get_invoice_amount', array($this, 'get_invoice_amount'));
        add_action('wp_ajax_nopriv_get_invoice_amount', array($this, 'get_invoice_amount'));
        add_action('wp_ajax_convert_currency', array($this, 'convert_currency'));
        add_action('wp_ajax_nopriv_convert_currency', array($this, 'convert_currency'));
        add_shortcode('invoice_display', array($this, 'invoice_display_shortcode'));
        add_action('admin_footer', array($this, 'add_admin_javascript'));
    }

    public function add_plugin_page() {
        add_options_page(
            'Currency Converter Settings',
            'Currency Converter',
            'manage_options',
            'currency-converter',
            array($this, 'create_admin_page')
        );
    }

    public function create_admin_page() {
        ?>
        <div class="wrap">
            <h1>Currency Converter Settings</h1>
            <form method="post" action="options.php">
            <?php
                settings_fields('currency_converter_option_group');
                do_settings_sections('currency-converter-admin');
                submit_button();
            ?>
            </form>
            <hr>
            <h2>Rial to Dollar Converter</h2>
            <div>
                <label for="rial_amount">Enter amount in Rials:</label>
                <input type="number" id="rial_amount" name="rial_amount">
                <button type="button" id="convert_to_dollar">Convert</button>
            </div>
            <div id="dollar_result"></div>
        </div>
        <?php
    }

    public function page_init() {
        register_setting(
            'currency_converter_option_group',
            'currency_converter_options',
            array($this, 'sanitize')
        );

        add_settings_section(
            'currency_converter_setting_section',
            'Exchange Rate Settings',
            array($this, 'print_section_info'),
            'currency-converter-admin'
        );

        add_settings_field(
            'dollar_exchange_rate',
            'Dollar Exchange Rate (in Rials)',
            array($this, 'dollar_exchange_rate_callback'),
            'currency-converter-admin',
            'currency_converter_setting_section'
        );
    }

    public function sanitize($input) {
        $new_input = array();
        if(isset($input['dollar_exchange_rate']))
            $new_input['dollar_exchange_rate'] = absint($input['dollar_exchange_rate']);

        return $new_input;
    }

    public function print_section_info() {
        print 'Enter the current dollar exchange rate below:';
    }

    public function dollar_exchange_rate_callback() {
        $options = get_option('currency_converter_options');
        $value = isset($options['dollar_exchange_rate']) ? $options['dollar_exchange_rate'] : '';
        printf(
            '<input type="text" id="dollar_exchange_rate" name="currency_converter_options[dollar_exchange_rate]" value="%s" />',
            esc_attr($value)
        );
    }

    public function currency_invoice_shortcode($atts) {
        $atts = shortcode_atts(
            array(
                'amount' => 0,
            ),
            $atts,
            'currency_invoice'
        );

        $invoice_id = uniqid();
        $dollar_amount = floatval($atts['amount']);
        $options = get_option('currency_converter_options');
        $exchange_rate = isset($options['dollar_exchange_rate']) ? $options['dollar_exchange_rate'] : 1;
        $rial_amount = $dollar_amount * $exchange_rate;

        $link = add_query_arg('invoice', $invoice_id, home_url('/invoice-display/'));

        update_option('invoice_' . $invoice_id, array(
            'dollar_amount' => $dollar_amount,
            'rial_amount' => $rial_amount
        ));

        return '<a href="' . esc_url($link) . '">View Invoice</a>';
    }

    public function currency_converter_shortcode() {
        wp_enqueue_script('jquery');
        
        ob_start();
        ?>
        <div id="currency-converter">
            <h3>Currency Converter</h3>
            <form id="currency-converter-form">
                <label for="dollar-amount">Enter amount in Dollars:</label>
                <input type="number" id="dollar-amount" name="dollar-amount" step="0.01" required>
                <button type="submit">Convert</button>
            </form>
            <div id="conversion-result"></div>
        </div>

        <script>
        jQuery(document).ready(function($) {
            $('#currency-converter-form').on('submit', function(e) {
                e.preventDefault();
                var dollarAmount = $('#dollar-amount').val();
                $.ajax({
                    url: '<?php echo admin_url('admin-ajax.php'); ?>',
                    type: 'POST',
                    data: {
                        action: 'convert_currency',
                        dollar_amount: dollarAmount
                    },
                    success: function(response) {
                        $('#conversion-result').html('<p>' + dollarAmount + ' USD = ' + response.rial_amount + ' Rials</p>');
                    }
                });
            });
        });
        </script>
        <?php
        return ob_get_clean();
    }

    public function convert_currency() {
        $dollar_amount = isset($_POST['dollar_amount']) ? floatval($_POST['dollar_amount']) : 0;
        $options = get_option('currency_converter_options');
        $exchange_rate = isset($options['dollar_exchange_rate']) ? $options['dollar_exchange_rate'] : 1;

        $rial_amount = $dollar_amount * $exchange_rate;

        wp_send_json(array(
            'rial_amount' => number_format($rial_amount, 0)
        ));
    }

    public function get_invoice_amount() {
        $invoice_id = isset($_POST['invoice_id']) ? sanitize_text_field($_POST['invoice_id']) : '';
        $invoice_data = get_option('invoice_' . $invoice_id, array('dollar_amount' => 0, 'rial_amount' => 0));
        $options = get_option('currency_converter_options');
        $exchange_rate = isset($options['dollar_exchange_rate']) ? $options['dollar_exchange_rate'] : 1;

        // Recalculate rial amount in case exchange rate has changed
        $rial_amount = $invoice_data['dollar_amount'] * $exchange_rate;

        wp_send_json(array(
            'dollar_amount' => number_format($invoice_data['dollar_amount'], 2),
            'rial_amount' => number_format($rial_amount, 0)
        ));
    }

    public function invoice_display_shortcode() {
        $invoice_id = isset($_GET['invoice']) ? sanitize_text_field($_GET['invoice']) : '';
        if(!$invoice_id) {
            return 'Invalid invoice.';
        }

        ob_start();
        ?>
        <div id="invoice-display">
            <h2>Invoice Details</h2>
            <p>Amount in Dollars: <span id="dollar-amount"></span></p>
            <p>Amount in Rials: <span id="rial-amount"></span></p>
        </div>
        <script>
        jQuery(document).ready(function($) {
            function updateInvoice() {
                $.ajax({
                    url: '<?php echo admin_url('admin-ajax.php'); ?>',
                    type: 'POST',
                    data: {
                        action: 'get_invoice_amount',
                        invoice_id: '<?php echo $invoice_id; ?>'
                    },
                    success: function(response) {
                        $('#dollar-amount').text(response.dollar_amount);
                        $('#rial-amount').text(response.rial_amount);
                    }
                });
            }

            updateInvoice();
            setInterval(updateInvoice, 60000); // Update every minute
        });
        </script>
        <?php
        return ob_get_clean();
    }

    public function add_admin_javascript() {
        ?>
        <script type="text/javascript">
        jQuery(document).ready(function($) {
            $('#convert_to_dollar').on('click', function() {
                var rialAmount = $('#rial_amount').val();
                var exchangeRate = $('#dollar_exchange_rate').val();
                if (rialAmount && exchangeRate) {
                    var dollarAmount = rialAmount / exchangeRate;
                    $('#dollar_result').html('<p>Equivalent in Dollars: $' + dollarAmount.toFixed(2) + '</p>');
                } else {
                    $('#dollar_result').html('<p>Please enter both Rial amount and exchange rate.</p>');
                }
            });
        });
        </script>
        <?php
    }
}

