=== Currency Converter Invoice ===
Contributors: Shahab Masoumi
Tags: invoice, currency converter, dollar, rial, currency exchange
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A professional plugin to create dollar-based invoices with live exchange rates and real-time currency conversion.

== Description ==

Currency Converter Invoice is a powerful tool that allows you to create invoices in dollars and display them with live rial conversion rates. It also includes a user-friendly currency converter that visitors can use directly on your website.

Features include:

* Set and manage dollar exchange rates
* Generate unique invoice links
* Display live invoice amounts based on current dollar rate
* Real-time currency converter for website visitors
* Easy to use shortcodes
* AJAX-powered calculations without page reload

== Installation ==

1. Upload the `currency-converter-invoice` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to Settings > Currency Converter to set the current dollar exchange rate

== Usage ==

The plugin provides two main shortcodes for easy integration into your WordPress site:

1. Invoice Generator Shortcode: [currency_invoice]

   This shortcode creates a link to view an invoice for a specified dollar amount. When clicked, it shows both the dollar amount and its equivalent in rials based on the current exchange rate.

   Usage:
   [currency_invoice amount="100"]

   Parameters:
   - amount: The invoice amount in dollars (required)

   Example:
   [currency_invoice amount="250.50"]

   This will create a link that, when clicked, displays an invoice for $250.50 with its rial equivalent.

2. Live Currency Converter Shortcode: [currency_converter]

   This shortcode creates an interactive form where users can enter a dollar amount and see its equivalent in rials instantly. The conversion is done in real-time using AJAX, without reloading the page.

   Usage:
   [currency_converter]

   This shortcode doesn't require any parameters. Simply place it on any page or post where you want the currency converter to appear.

   Example:
   [currency_converter]

   This will display a form with an input field for the dollar amount and a button to convert it to rials.

== Frequently Asked Questions ==

= How do I create an invoice? =
Use the shortcode [currency_invoice amount="100"] in your posts or pages, replacing 100 with your actual invoice amount in dollars.

= How do I add a currency converter to my page? =
Simply add the shortcode [currency_converter] wherever you want the conversion form to appear.

= How often is the dollar rate updated? =
The dollar rate is manually set in the plugin settings. You need to update it regularly to ensure accurate conversions.

= Can I use this plugin in my language? =
Currently, the plugin supports English and Persian interfaces. More languages will be added in future updates.

== Screenshots ==

1. Currency converter interface
2. Invoice display page
3. Admin settings panel

== Changelog ==

= 1.0 =
* Initial release
* Added invoice generator shortcode [currency_invoice]
* Added live currency converter shortcode [currency_converter]
* Added admin settings panel for exchange rate management

== Upgrade Notice ==

= 1.0 =
Initial release with all core features implemented.

== Support ==

For support and more information, please visit [https://netsam.ir](https://netsam.ir)

